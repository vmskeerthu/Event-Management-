package com.example.atry;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
Button clk;
VideoView videov;
MediaController mediaC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
clk=findViewById(R.id.button);
videov=findViewById(R.id.videoView);
mediaC=new MediaController(this);

    }
    public void videoplay(View v){
String videopath="android.resource://com.example.atry/"+R.raw.example;
Uri uri= Uri.parse(videopath);
videov.setVideoURI(uri);
videov.setMediaController(mediaC);
mediaC.setAnchorView(videov);
videov.start();
    }
}