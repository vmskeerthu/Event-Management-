package com.example.atry;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BookEvent extends AppCompatActivity {
String[] item={"Birthday","Wedding","Celebration"};
String[] themes={"Cartoon","Forest","Palace"};
String[] venue={"Coimbatore","Chennai","Salem"};
AutoCompleteTextView autoCompleteTextView;
TextView text;
ImageView button;
AutoCompleteTextView auto_complete_txt1;
AutoCompleteTextView auto_complete_txt2;
ArrayAdapter<String> adapterItems;
ArrayAdapter<String> adapterItems1;
ArrayAdapter<String> adapterItems2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_event);
        text=findViewById(R.id.showText);
        button=findViewById(R.id.date);
        autoCompleteTextView=findViewById(R.id.auto_complete_txt);
        auto_complete_txt1=findViewById(R.id.auto_complete_txt1);
        auto_complete_txt2=findViewById(R.id.auto_complete_txt2);
        adapterItems=new ArrayAdapter<String> (this, R.layout.list_item,item);
        adapterItems1=new ArrayAdapter<String>(this,R.layout.list_item,themes);
        adapterItems2=new ArrayAdapter<String>(this,R.layout.list_item,venue);
        autoCompleteTextView.setAdapter(adapterItems);
        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(BookEvent.this,"Item:"+item,Toast.LENGTH_SHORT).show();
            }
        });
        auto_complete_txt1.setAdapter(adapterItems1);
        auto_complete_txt1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String themes=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(BookEvent.this,"Item:"+themes,Toast.LENGTH_SHORT).show();
            }
        });
        auto_complete_txt2.setAdapter(adapterItems2);
        auto_complete_txt2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String venue=adapterView.getItemAtPosition(i).toString();
                Toast.makeText(BookEvent.this,"Item:"+venue,Toast.LENGTH_SHORT).show();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });
    }
    private void openDialog(){
        DatePickerDialog dialog=new DatePickerDialog(this,R.style.DialogTheme, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                text.setText(String.valueOf(year)+"."+String.valueOf(month+1)+"."+String.valueOf(day));
            }
        }, 2024, 4, 15);
        dialog.show();
    }

}